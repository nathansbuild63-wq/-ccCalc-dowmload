/**
 * function/history.js
 */

function loadHistoryData() {
    // Check if configuration exists
    const key = (typeof DEVICE_STORAGE_CONFIG !== 'undefined') 
                ? DEVICE_STORAGE_CONFIG.HISTORY_KEY 
                : "calc_history_data";
    
    const rawData = localStorage.getItem(key);
    return rawData ? JSON.parse(rawData) : [];
}

function restoreValue(value) {
    // Send message to parent (index.html) to update the current value
    window.parent.postMessage({
        type: 'RESTORE_VALUE',
        data: value.toString()
    }, '*');
    
    console.log("[History] Sent restore request: " + value);
    
    // Optional: Close history overlay after selecting
    if (window.parent.toggleHistory) {
        window.parent.toggleHistory();
    }
}

function renderHistory(containerId) {
    const container = document.getElementById(containerId);
    const data = loadHistoryData();

    if (data.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding:20px;">No history found. Try calculating something!</div>';
        return;
    }

    // Added onclick="restoreValue" to the items
    container.innerHTML = data.map(item => `
        <div class="history-item" onclick="restoreValue('${item.result}')" style="cursor:pointer;">
            <div class="math-row">
                <span class="equation">${item.equation}</span>
                <span class="result">${item.result}</span>
            </div>
            <div class="time-stamp">${new Date(item.timestamp).toLocaleTimeString()}</div>
        </div>
    `).join('');
}
