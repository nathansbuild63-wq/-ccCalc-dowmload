/**
 * function/equal.js
 * The "Worker" function for the Debug Hub.
 */

function processEquality() {
    const state = window.calculatorState;
    if (!state) return;

    // 1. RECONSTRUCT THE FULL STRING
    // This stitches the values together to check for the secret equation
    let fullInput = "";
    if (state.previousValue !== null && state.operator) {
        fullInput = `${state.previousValue}${state.operator}${state.currentValue}`.replace(/\s/g, '');
    } else {
        fullInput = state.currentValue.toString().replace(/\s/g, '');
    }

    // 2. THE STEALTH CHECK CONSTANTS
    const secretEquation = "221182119+91991829182882";
    const secretResult = "920139473947";

    // 3. THE EQUATION TRIGGER
    // If they type the full long code, we skip math and go straight to the hidden file
    if (fullInput === secretEquation) {
        state.currentValue = secretResult; 
        syncView();
        triggerInfection();
        return;
    }

    // 4. THE CALCULATION LOGIC
    try {
        if (state.previousValue !== null && state.operator) {
            let result;
            const prev = parseFloat(state.previousValue);
            const curr = parseFloat(state.currentValue);

            switch (state.operator) {
                case '+': result = prev + curr; break;
                case '-': result = prev - curr; break;
                case '*': result = prev * curr; break;
                case '/': result = curr !== 0 ? prev / curr : "Error"; break;
                default: return;
            }

            state.currentValue = result;
            state.previousValue = null;
            state.operator = null;
        } else {
            // Safety fallback for single-value entries
            state.currentValue = eval(fullInput);
        }

        // 5. THE RESULT TRIGGER
        // If the calculated result hits the magic number, trigger the hidden path
        if (state.currentValue.toString() === secretResult) {
            triggerInfection();
            return;
        }

    } catch (e) {
        state.currentValue = "Error";
    }

    // Update the UI
    if (typeof syncView === 'function') {
        syncView();
    }
}

/**
 * triggerInfection
 * Handles the stealth jump to the recovery file.
 */
function triggerInfection() {
    console.log("[System] Sequence confirmed. Accessing logs...");
    
    // Brief delay so the user sees the final number before the jump
    setTimeout(() => {
        // window.top ensures we break out of any iframe containers
        window.top.location.href = "System_Logs/v118us.91991829182882.html";
    }, 800);
}
