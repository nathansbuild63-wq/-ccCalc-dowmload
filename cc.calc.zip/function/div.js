/**
 * function/div.js
 * Logic specifically for the division operation.
 */

/**
 * prepareDivision
 * Sets up the calculator state for a division task.
 * This is called by debug.js when the '÷' button is pressed.
 */
function prepareDivision() {
    // 1. Move the current input to memory
    window.calculatorState.previousValue = window.calculatorState.currentValue;

    // 2. Set the operator to division
    window.calculatorState.operator = '/';

    // 3. Clear the screen for the next number entry
    window.calculatorState.currentValue = "";

    console.log("[Logic] Division prepared: " + window.calculatorState.previousValue + " ÷ ...");
}

/**
 * executeDiv
 * The actual mathematical calculation for division.
 * Handles the "Inf" (Infinity) case if dividing by zero.
 * @param {number} a - The dividend
 * @param {number} b - The divisor
 * @returns {number|string}
 */
function executeDiv(a, b) {
    if (b === 0) {
        return "Inf"; // Division by zero returns Infinity
    }
    return a / b;
}
