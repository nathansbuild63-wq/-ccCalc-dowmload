/**
 * function/mul.js
 * Logic specifically for the multiplication operation.
 */

/**
 * prepareMultiplication
 * Sets up the calculator state for a multiplication task.
 * Called by debug.js when '×' (sent as '*') is pressed.
 */
function prepareMultiplication() {
    // 1. Move the current input to the background memory
    window.calculatorState.previousValue = window.calculatorState.currentValue;

    // 2. Set the operator to multiplication
    window.calculatorState.operator = '*';

    // 3. Reset the current display value for the next number
    window.calculatorState.currentValue = "";

    console.log("[Logic] Multiplication prepared: " + window.calculatorState.previousValue + " × ...");
}

/**
 * executeMul
 * The actual mathematical calculation for multiplication.
 * @param {number} a - The first factor
 * @param {number} b - The second factor
 * @returns {number}
 */
function executeMul(a, b) {
    return a * b;
}
