/**
 * function/add.js
 * Logic specifically for the addition operation.
 */

/**
 * prepareAddition
 * Sets up the calculator state for an addition task.
 * This is called by debug.js when the '+' button is pressed.
 */
function prepareAddition() {
    // 1. Store the current number as the 'previousValue'
    window.calculatorState.previousValue = window.calculatorState.currentValue;

    // 2. Set the operator to addition
    window.calculatorState.operator = '+';

    // 3. Clear the current value so the user can type the second number
    // We set it to an empty string so typer.js knows to start fresh
    window.calculatorState.currentValue = "";

    console.log("[Logic] Addition prepared: " + window.calculatorState.previousValue + " + ...");
}

/**
 * executeAdd
 * The actual mathematical calculation for addition.
 * @param {number} a - The first number
 * @param {number} b - The second number
 * @returns {number}
 */
function executeAdd(a, b) {
    return a + b;
}
