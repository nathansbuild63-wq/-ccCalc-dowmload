/**
 * function/listener%open.js
 */

const myMessages = [
   "sysopener.env-responded.env" // Added quotes here
];

let listenerActive = false;
let commandLocked = false; // Prevents the fetch from looping forever

function initializeListener() {
    console.log("[System] Listener active and watching...");

    setInterval(() => {
        const input = window.calculatorState.currentValue.toString().toLowerCase().trim();

        // 1. Unlock Command
        if (input === "open" && !listenerActive) {
            listenerActive = true;
            window.calculatorState.currentValue = "hi you can now access this";
            if (typeof syncView === 'function') syncView();
            return;
        }

        // 2. Processing Commands
        if (listenerActive && !commandLocked) {
            myMessages.forEach(pair => {
                const parts = pair.split('-');
                const trigger = parts[0].toLowerCase().trim();
                const responseFile = parts[1];
                
                if (input === trigger) {
                    commandLocked = true; // Stop multiple fetches
                    fetchEnvAndRespond(responseFile);
                }
            });
        }
        
        // Reset lock if the user clears the display or types something else
        if (commandLocked && !myMessages.some(p => input === p.split('-')[0].toLowerCase())) {
            commandLocked = false;
        }
    }, 500); 
}

async function fetchEnvAndRespond(fileName) {
    try {
        // Path corrected: index.html is the boss, so we start from its location
        const response = await fetch(`strings/uri/s/${fileName}`);
        if (!response.ok) throw new Error("File not found");
        
        const text = await response.text();
        
        window.calculatorState.currentValue = text.trim();
        if (typeof syncView === 'function') syncView();
        
    } catch (err) {
        console.error(`[Listener] Error fetching ${fileName}:`, err);
        window.calculatorState.currentValue = "File Error";
        if (typeof syncView === 'function') syncView();
    }
}

initializeListener();
