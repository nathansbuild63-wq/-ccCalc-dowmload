/**
 * function/math.js
 * The "Engine" that performs the actual arithmetic.
 */

/**
 * calculateFinalResult
 * Takes the stored values and operator and returns a final answer.
 */
function calculateFinalResult(a, b, operator) {
    let result = 0;

    // Route to the specific execution functions in your modules
    switch (operator) {
        case '+':
            // Calls executeAdd from add.js
            result = executeAdd(a, b);
            break;
        case '-':
            // Calls executeSub from sub.js
            result = executeSub(a, b);
            break;
        case '*':
            // Calls executeMul from mul.js
            result = executeMul(a, b);
            break;
        case '/':
            // Calls executeDiv from div.js
            result = executeDiv(a, b);
            break;
        default:
            return "Error";
    }

    // Handle special mathematical results
    if (result === Infinity || result === -Infinity) {
        return "Inf";
    }

    if (isNaN(result)) {
        return "Error";
    }

    // Format the number so it doesn't break the LCD display
    // If it's a long decimal, we limit it to 8 places
    if (result.toString().length > 10) {
        return parseFloat(result.toFixed(8));
    }

    return result;
}