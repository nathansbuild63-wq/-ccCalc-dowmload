/**
 * function/save%data.js
 * Handles the persistent storage of calculation history on the device.
 */

/**
 * saveEquation
 * Called by debug.js when the "=" button is pressed.
 */
function saveEquation(equation, result) {
    try {
        // 1. Fetch existing history or start with an empty array
        // Uses the key defined in strings/save%data%device.js
        const storageKey = DEVICE_STORAGE_CONFIG.HISTORY_KEY;
        const rawData = localStorage.getItem(storageKey);
        let history = rawData ? JSON.parse(rawData) : [];

        // 2. Create the new history entry object
        const newEntry = {
            id: Date.now(),
            equation: equation, // e.g., "5 + 5"
            result: result,     // e.g., "10"
            timestamp: new Date().toISOString()
        };

        // 3. Add to the top of the list (newest first)
        history.unshift(newEntry);

        // 4. Limit the number of saved items to keep performance high
        const maxEntries = DEVICE_STORAGE_CONFIG.MAX_ENTRIES || 20;
        if (history.length > maxEntries) {
            history = history.slice(0, maxEntries);
        }

        // 5. Commit to LocalStorage
        localStorage.setItem(storageKey, JSON.stringify(history));
        
        console.log("[Storage] Equation saved successfully.");
    } catch (error) {
        console.error("[Storage Error] Could not save equation:", error);
    }
}

/**
 * clearAllData
 * Wipes the history from the device.
 */
function clearAllData() {
    const storageKey = DEVICE_STORAGE_CONFIG.HISTORY_KEY;
    localStorage.removeItem(storageKey);
    console.log("[Storage] All history data cleared.");
}