/**
 * function/util.js
 * Logic for the 'C' (Clear) and 'back' (Backspace) buttons.
 */

/**
 * resetCalculator
 * Wipes the calculator state and returns display to "0".
 */
function resetCalculator() {
    console.log("[Util] Performing Full Reset");
    
    // Reset the global state object
    window.calculatorState.currentValue = "0";
    window.calculatorState.previousValue = null;
    window.calculatorState.operator = null;
    window.calculatorState.isError = false;
}

/**
 * handleErase
 * Removes the last digit or handles error states.
 */
function handleErase() {
    let current = window.calculatorState.currentValue;

    // 1. If the display is showing "Error", "Inf", or is already "0", just reset it
    if (current === "Error" || current === "ERROR!" || current === "Inf" || current === "0") {
        window.calculatorState.currentValue = "0";
        return;
    }

    // 2. Remove the last character
    if (current.length > 1) {
        window.calculatorState.currentValue = current.slice(0, -1);
    } else {
        // 3. If it was the last digit, go back to "0"
        window.calculatorState.currentValue = "0";
    }

    console.log("[Util] Deleted last character. Current value: " + window.calculatorState.currentValue);
}
