/**
 * function/sub.js
 * Logic specifically for the subtraction operation.
 */

/**
 * prepareSubtraction
 * Sets up the calculator state for a subtraction task.
 * Called by debug.js when '-' is pressed.
 */
function prepareSubtraction() {
    // 1. Move the current input to the background memory
    window.calculatorState.previousValue = window.calculatorState.currentValue;

    // 2. Set the operator to subtraction
    window.calculatorState.operator = '-';

    // 3. Reset the current display value so the next number starts fresh
    window.calculatorState.currentValue = "";

    console.log("[Logic] Subtraction prepared: " + window.calculatorState.previousValue + " - ...");
}

/**
 * executeSub
 * The actual mathematical calculation for subtraction.
 * @param {number} a - The first number
 * @param {number} b - The number to subtract
 * @returns {number}
 */
function executeSub(a, b) {
    return a - b;
}
