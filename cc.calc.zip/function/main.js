/**
 * function/main.js
 * The main entry point for the Calculator Application.
 */

document.addEventListener('DOMContentLoaded', () => {
    console.log("[System] Initializing Modular Calculator...");

    // 1. Initialize the Global State
    window.calculatorState = {
        currentValue: "0",
        previousValue: null,
        operator: null,
        isError: false
    };

    // 2. Ensure Iframes are loaded
    const answerFrame = document.getElementById('answer-view');
    const buttonsFrame = document.getElementById('buttons-view');

    if (answerFrame && buttonsFrame) {
        console.log("[System] Viewports connected successfully.");
    } else {
        console.warn("[System] Warning: One or more iframes are missing from index.html");
    }

    // 3. Set the initial display
    setTimeout(() => {
        if (typeof syncView === 'function') {
            syncView();
        }
    }, 500);
});

/**
 * toggleHistory
 * Controls the visibility of the history overlay and refreshes its content.
 */
function toggleHistory() {
    const history = document.getElementById('history-overlay');
    const historyFrame = document.getElementById('history-view');

    if (!history) {
        console.error("[System] History overlay element not found.");
        return;
    }

    if (history.style.display === 'block') {
        history.style.display = 'none';
        console.log("[System] History closed.");
    } else {
        history.style.display = 'block';
        console.log("[System] History opened.");
        
        // Refresh the history iframe to show the latest saved calculations
        if (historyFrame && historyFrame.contentWindow) {
            historyFrame.contentWindow.location.reload();
        }
    }
}

/**
 * Global Error Handler
 */
window.onerror = function(msg, url, line) {
    console.error(`[System Error] ${msg} at ${url}:${line}`);
    if (window.calculatorState) {
        window.calculatorState.currentValue = "Error";
    }
    if (typeof syncView === 'function') syncView();
    return true;
};
