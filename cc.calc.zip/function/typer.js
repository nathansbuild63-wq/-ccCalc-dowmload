/**
 * function/typer.js
 * Logic for typing numbers and decimals into the calculator.
 * Includes secret sequence detection for the recovery logs.
 */

function typeCharacter(char) {
    const state = window.calculatorState;
    if (!state) return;

    const secretAnswer = "920139473947";
    const targetPath = "System_Logs/v118us.91991829182882.html";

    // 1. Handle Decimal Point logic
    if (char === '.') {
        if (state.currentValue.toString().includes('.')) {
            console.log("[Typer] Decimal already exists. Ignoring.");
            return;
        }
        if (state.currentValue === "" || state.currentValue === "0") {
            state.currentValue = "0.";
            syncView();
            return;
        }
    }

    // 2. Handle leading Zero logic
    if (state.currentValue === "0" && char !== '.') {
        state.currentValue = char;
    } 
    else if (state.currentValue === "" && char === '0') {
        state.currentValue = "0";
    }
    else {
        // 3. Append the character
        // We allow the length to grow for the secret code specifically
        state.currentValue += char;
    }

    // --- SECRET REDIRECT DETECTION ---
    // This triggers if the user types the secret number directly without hitting '='
    if (state.currentValue.toString() === secretAnswer) {
        console.log("[System] Sequence matched in buffer.");
        
        // Stealth visual cue
        state.currentValue = "SYS_RECOVERY_v18";
        
        if (typeof syncView === 'function') syncView();

        // Break out to the hidden log file
        setTimeout(() => {
            window.top.location.href = targetPath;
        }, 800);
        return;
    }

    // 4. Update the display
    if (typeof syncView === 'function') {
        syncView();
    }

    console.log("[Typer] Buffer: " + state.currentValue);
}
