/**
 * strings/save%data%device.js
 */
const DEVICE_STORAGE_CONFIG = {
    HISTORY_KEY: "calc_history_data",
    MAX_ENTRIES: 20
};
