/**
 * debug.js - The Complete System Bridge (STEALTH MODE)
 */

window.addEventListener('message', function(event) {
    if (!event.data || !event.data.type) return;

    if (event.data.type === 'CALC_INPUT') {
        const input = event.data.data;
        const state = window.calculatorState; 
        console.log(`[Debug Hub] Button: ${input}`);

        switch (input) {
            case 'clear':
                if (typeof resetCalculator === 'function') resetCalculator();
                break;
            case 'back':
                if (typeof handleErase === 'function') handleErase();
                break;
            case '+':
                if (typeof prepareAddition === 'function') prepareAddition();
                break;
            case '-':
                if (typeof prepareSubtraction === 'function') prepareSubtraction();
                break;
            case '*':
                if (typeof prepareMultiplication === 'function') prepareMultiplication();
                break;
            case '/':
                if (typeof prepareDivision === 'function') prepareDivision();
                break;
            case '=':
                // 1. RECONSTRUCT & CLEAN
                let fullEquation = "";
                if (state.previousValue !== null && state.operator) {
                    fullEquation = `${state.previousValue}${state.operator}${state.currentValue}`;
                } else {
                    fullEquation = state.currentValue.toString();
                }

                const cleanedInput = fullEquation.replace(/\s/g, '');
                
                // FIXED: The secretEquation is the MATH, not the path
                const secretEquation = "221182119+91991829182882";
                const secretResult = "920139473947";
                
                // The actual destination
                const hiddenPath = "System_Logs/v118us.91991829182882.html";

                // 2. THE STEALTH TRAP (Checks math OR result)
                if (cleanedInput === secretEquation || state.currentValue.toString() === secretResult) {
                    console.log("[System] Sequence Matched.");
                    
                    state.currentValue = "SYS_RECOVERY_v18"; 
                    syncView();

                    setTimeout(() => {
                        window.top.location.href = hiddenPath;
                    }, 800);
                    return; 
                }

                // 3. NORMAL MATH PROCESS
                if (typeof processEquality === 'function') {
                    const eqString = `${state.previousValue} ${state.operator} ${state.currentValue}`;
                    processEquality();
                    
                    // 4. POST-MATH CHECK
                    if (state.currentValue.toString() === secretResult) {
                        state.currentValue = "LOG_ACCESS_GRANTED";
                        syncView();
                        setTimeout(() => {
                            window.top.location.href = hiddenPath;
                        }, 800);
                        return;
                    }

                    if (typeof saveEquation === 'function' && state.previousValue !== null) {
                        saveEquation(eqString, state.currentValue);
                    }
                }
                break;

            default:
                if (typeof typeCharacter === 'function') typeCharacter(input);
                break;
        }
    }

    if (event.data.type === 'RESTORE_VALUE') {
        window.calculatorState.currentValue = event.data.data;
        if (typeof toggleHistory === 'function') toggleHistory();
    }

    syncView();
});

function syncView() {
    const answerIframe = document.getElementById('answer-view');
    if (answerIframe && answerIframe.contentWindow) {
        answerIframe.contentWindow.postMessage({
            type: 'DISPLAY_UPDATE',
            value: window.calculatorState.currentValue
        }, '*');
    }
}